lon_max=max(RN(:,6));
lon_min=min(RN(:,6));
lat_max=max(RN(:,5));
lat_min=min(RN(:,5));
lon_internal=(lon_max-lon_min)/3;
lat_internal=(lat_max-lat_min)/3;
RN1=[];RN2=[];RN3=[];RN4=[];RN5=[];RN6=[];RN7=[];RN8=[];RN9=[];
for ii=1:length_RN%�������ң����ϵ���
    if RN(ii,6)<lon_min+lon_internal&&RN(ii,5)>lat_min+lat_internal*2
        RN1=[RN1;RN(ii,:)];
    elseif RN(ii,6)<lon_min+lon_internal&&RN(ii,5)>lat_min+lat_internal&&RN(ii,5)<lat_min+lat_internal*2
        RN4=[RN4;RN(ii,:)];
    elseif RN(ii,6)<lon_min+lon_internal&&RN(ii,5)<lat_min+lat_internal
        RN7=[RN7;RN(ii,:)];
    elseif RN(ii,6)<lon_min+lon_internal*2&&RN(ii,6)>lon_min+lon_internal&&RN(ii,5)>lat_min+lat_internal*2
        RN2=[RN2;RN(ii,:)];
    elseif RN(ii,6)<lon_min+lon_internal*2&&RN(ii,6)>lon_min+lon_internal&&RN(ii,5)>lat_min+lat_internal&&RN(ii,5)<lat_min+lat_internal*2
        RN5=[RN5;RN(ii,:)];
    elseif RN(ii,6)<lon_min+lon_internal*2&&RN(ii,6)>lon_min+lon_internal&&RN(ii,5)<lat_min+lat_internal
        RN8=[RN8;RN(ii,:)];
    elseif RN(ii,6)>lon_min+lon_internal*2&&RN(ii,5)>lat_min+lat_internal*2
        RN3=[RN3;RN(ii,:)];
    elseif RN(ii,6)>lon_min+lon_internal*2&&RN(ii,5)>lat_min+lat_internal&&RN(ii,5)<lat_min+lat_internal*2
        RN6=[RN6;RN(ii,:)];
    else
        RN9=[RN9;RN(ii,:)];
    end
end
save('RN1.mat','RN1');
save('RN2.mat','RN2');
save('RN3.mat','RN3');
save('RN4.mat','RN4');
save('RN5.mat','RN5');
save('RN6.mat','RN6');
save('RN7.mat','RN7');
save('RN8.mat','RN8');
save('RN9.mat','RN9');